import { NgxMatTimepickerComponent } from './timepicker.component';
export { NgxMatTimepickerComponent };
/**
 * @deprecated Use NgxMatTimepickerComponent directly as a standalone component
 */
export declare class NgxMatTimepickerModule {
}
