/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@mehranjavid/datetime-picker" />
export * from './public-api';
