import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "./material/input/input-module";
import * as i3 from "@angular/forms";
import * as i4 from "./material/icon/icon-module";
import * as i5 from "./material/button/button-module";
import * as i6 from "./timepicker.component";
export declare class NgxMatTimepickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxMatTimepickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NgxMatTimepickerModule, never, [typeof i1.CommonModule, typeof i2.MatInputModule, typeof i3.ReactiveFormsModule, typeof i3.FormsModule, typeof i4.MatIconModule, typeof i5.MatButtonModule, typeof i6.NgxMatTimepickerComponent], [typeof i6.NgxMatTimepickerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NgxMatTimepickerModule>;
}
