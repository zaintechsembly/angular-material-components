import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "./material/datepicker/datepicker-module";
import * as i3 from "./material/dialog/dialog-module";
import * as i4 from "@angular/cdk/portal";
import * as i5 from "@angular/forms";
import * as i6 from "./material/icon/icon-module";
import * as i7 from "./material/button/button-module";
import * as i8 from "./material/input/input-module";
import * as i9 from "./timepicker.module";
import * as i10 from "./datetime-picker.component";
import * as i11 from "./datetime-input";
import * as i12 from "./calendar";
import * as i13 from "./month-view";
import * as i14 from "./year-view";
import * as i15 from "./multi-year-view";
export declare class NgxMatDatetimePickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxMatDatetimePickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NgxMatDatetimePickerModule, never, [typeof i1.CommonModule, typeof i2.MatDatepickerModule, typeof i3.MatDialogModule, typeof i4.PortalModule, typeof i5.FormsModule, typeof i6.MatIconModule, typeof i7.MatButtonModule, typeof i8.MatInputModule, typeof i9.NgxMatTimepickerModule, typeof i10.NgxMatDatetimePicker, typeof i10.NgxMatDatetimeContent, typeof i11.NgxMatDatetimeInput, typeof i12.NgxMatCalendar, typeof i13.NgxMatMonthView, typeof i14.NgxMatYearView, typeof i15.NgxMatMultiYearView, typeof i12.NgxMatCalendarHeader], [typeof i10.NgxMatDatetimePicker, typeof i11.NgxMatDatetimeInput, typeof i12.NgxMatCalendar, typeof i13.NgxMatMonthView, typeof i14.NgxMatYearView, typeof i15.NgxMatMultiYearView, typeof i12.NgxMatCalendarHeader]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NgxMatDatetimePickerModule>;
}
