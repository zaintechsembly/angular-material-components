import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "../core/ripple/index";
import * as i3 from "../core/common-behaviors/common-module";
import * as i4 from "./button";
export declare class MatButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatButtonModule, never, [typeof i1.CommonModule, typeof i2.MatRippleModule, typeof i3.MatCommonModule, typeof i4.MatButton, typeof i4.MatAnchor], [typeof i4.MatButton, typeof i4.MatAnchor, typeof i3.MatCommonModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatButtonModule>;
}
