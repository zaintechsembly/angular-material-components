import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "../button/button-module";
import * as i3 from "../dialog/dialog-module";
import * as i4 from "@angular/cdk/overlay";
import * as i5 from "@angular/cdk/a11y";
import * as i6 from "@angular/cdk/portal";
import * as i7 from "./calendar";
import * as i8 from "./calendar-body";
import * as i9 from "./datepicker";
import * as i10 from "./datepicker-input";
import * as i11 from "./datepicker-toggle";
import * as i12 from "./month-view";
import * as i13 from "./year-view";
import * as i14 from "./multi-year-view";
export declare class MatDatepickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatDatepickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatDatepickerModule, never, [typeof i1.CommonModule, typeof i2.MatButtonModule, typeof i3.MatDialogModule, typeof i4.OverlayModule, typeof i5.A11yModule, typeof i6.PortalModule, typeof i7.MatCalendar, typeof i8.MatCalendarBody, typeof i9.MatDatepicker, typeof i9.MatDatepickerContent, typeof i10.MatDatepickerInput, typeof i11.MatDatepickerToggle, typeof i11.MatDatepickerToggleIcon, typeof i12.MatMonthView, typeof i13.MatYearView, typeof i14.MatMultiYearView, typeof i7.MatCalendarHeader], [typeof i7.MatCalendar, typeof i8.MatCalendarBody, typeof i9.MatDatepicker, typeof i9.MatDatepickerContent, typeof i10.MatDatepickerInput, typeof i11.MatDatepickerToggle, typeof i11.MatDatepickerToggleIcon, typeof i12.MatMonthView, typeof i13.MatYearView, typeof i14.MatMultiYearView, typeof i7.MatCalendarHeader]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatDatepickerModule>;
}
