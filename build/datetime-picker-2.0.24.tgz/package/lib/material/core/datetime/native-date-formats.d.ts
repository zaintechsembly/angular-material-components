/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { MatDateFormats } from './date-formats';
export declare const MAT_NATIVE_DATE_FORMATS: MatDateFormats;
