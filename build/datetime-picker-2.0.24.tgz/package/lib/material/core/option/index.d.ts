import * as i0 from "@angular/core";
import * as i1 from "../ripple/index";
import * as i2 from "@angular/common";
import * as i3 from "../selection/index";
import * as i4 from "./option";
import * as i5 from "./optgroup";
export declare class MatOptionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatOptionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatOptionModule, never, [typeof i1.MatRippleModule, typeof i2.CommonModule, typeof i3.MatPseudoCheckboxModule, typeof i4.MatOption, typeof i5.MatOptgroup], [typeof i4.MatOption, typeof i5.MatOptgroup]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatOptionModule>;
}
export * from './option';
export * from './optgroup';
