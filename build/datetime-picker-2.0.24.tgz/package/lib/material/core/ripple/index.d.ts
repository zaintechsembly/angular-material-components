import * as i0 from "@angular/core";
import * as i1 from "../common-behaviors/common-module";
import * as i2 from "@angular/cdk/platform";
import * as i3 from "./ripple";
export * from './ripple';
export * from './ripple-ref';
export * from './ripple-renderer';
export declare class MatRippleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatRippleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatRippleModule, never, [typeof i1.MatCommonModule, typeof i2.PlatformModule, typeof i3.MatRipple], [typeof i3.MatRipple, typeof i1.MatCommonModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatRippleModule>;
}
