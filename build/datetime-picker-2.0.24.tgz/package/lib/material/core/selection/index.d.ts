import * as i0 from "@angular/core";
import * as i1 from "./pseudo-checkbox/pseudo-checkbox";
export declare class MatPseudoCheckboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatPseudoCheckboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatPseudoCheckboxModule, never, [typeof i1.MatPseudoCheckbox], [typeof i1.MatPseudoCheckbox]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatPseudoCheckboxModule>;
}
export * from './pseudo-checkbox/pseudo-checkbox';
