/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import * as i0 from "@angular/core";
/**
 * Directive to automatically resize a textarea to fit its content.
 * @deprecated Use `cdkTextareaAutosize` from `@angular/cdk/text-field` instead.
 * @breaking-change 8.0.0
 */
export declare class MatTextareaAutosize extends CdkTextareaAutosize {
    get matAutosizeMinRows(): number;
    set matAutosizeMinRows(value: number);
    get matAutosizeMaxRows(): number;
    set matAutosizeMaxRows(value: number);
    get matAutosize(): boolean;
    set matAutosize(value: boolean);
    get matTextareaAutosize(): boolean;
    set matTextareaAutosize(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatTextareaAutosize, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatTextareaAutosize, "textarea[mat-autosize], textarea[matTextareaAutosize]", ["matTextareaAutosize"], { "cdkAutosizeMinRows": { "alias": "cdkAutosizeMinRows"; "required": false; }; "cdkAutosizeMaxRows": { "alias": "cdkAutosizeMaxRows"; "required": false; }; "matAutosizeMinRows": { "alias": "matAutosizeMinRows"; "required": false; }; "matAutosizeMaxRows": { "alias": "matAutosizeMaxRows"; "required": false; }; "matAutosize": { "alias": "mat-autosize"; "required": false; }; "matTextareaAutosize": { "alias": "matTextareaAutosize"; "required": false; }; }, {}, never, never, true, never>;
}
