import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/cdk/text-field";
import * as i3 from "../form-field/form-field-module";
import * as i4 from "./input";
import * as i5 from "./autosize";
export declare class MatInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatInputModule, never, [typeof i1.CommonModule, typeof i2.TextFieldModule, typeof i3.MatFormFieldModule, typeof i4.MatInput, typeof i5.MatTextareaAutosize], [typeof i2.TextFieldModule, typeof i3.MatFormFieldModule, typeof i4.MatInput, typeof i5.MatTextareaAutosize]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatInputModule>;
}
