import * as i0 from "@angular/core";
/** Prefix to be placed in front of the form field. */
export declare class MatPrefix {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatPrefix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatPrefix, "[matPrefix]", never, {}, {}, never, never, true, never>;
}
