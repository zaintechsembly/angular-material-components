import * as i0 from "@angular/core";
/** Single error message to be shown underneath the form field. */
export declare class MatError {
    id: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatError, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatError, "mat-error", never, { "id": { "alias": "id"; "required": false; }; }, {}, never, never, true, never>;
}
