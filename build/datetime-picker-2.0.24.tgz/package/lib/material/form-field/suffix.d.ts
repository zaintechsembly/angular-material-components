import * as i0 from "@angular/core";
/** Suffix to be placed at the end of the form field. */
export declare class MatSuffix {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatSuffix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatSuffix, "[matSuffix]", never, {}, {}, never, never, true, never>;
}
