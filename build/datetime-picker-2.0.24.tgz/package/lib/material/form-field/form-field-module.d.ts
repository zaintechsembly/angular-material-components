import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/cdk/observers";
import * as i3 from "./error";
import * as i4 from "./form-field";
import * as i5 from "./hint";
import * as i6 from "./label";
import * as i7 from "./placeholder";
import * as i8 from "./prefix";
import * as i9 from "./suffix";
export declare class MatFormFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatFormFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatFormFieldModule, never, [typeof i1.CommonModule, typeof i2.ObserversModule, typeof i3.MatError, typeof i4.MatFormField, typeof i5.MatHint, typeof i6.MatLabel, typeof i7.MatPlaceholder, typeof i8.MatPrefix, typeof i9.MatSuffix], [typeof i3.MatError, typeof i4.MatFormField, typeof i5.MatHint, typeof i6.MatLabel, typeof i7.MatPlaceholder, typeof i8.MatPrefix, typeof i9.MatSuffix]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatFormFieldModule>;
}
